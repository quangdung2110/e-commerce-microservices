# Inventory Reserve benchmark — flash-smoke

## baseline-flash

| Orders/s | RESERVED/s | Finished/s | SLO | Reserve hot p50 / p95 / p99 ms | Commit hot p50 / p95 / p99 ms | Busy | Unavail. | Timeout | Not reserved | Dropped res / fin | Lock stmt mean ms | Lock waiters mean/max | Hikari pending mean/max | CPU inv / pg % | Correct |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 50 | 50.0 | 50.0 | yes | 6.6 / 11.5 / 15.3 | 5.5 / 11.0 / 14.9 | 0 | 0 | 0 | 0 | 0 / 0 | 1.1 | 0.3 / 1 | 0.0 / 0 | 27 / 21 | yes |
| 150 | 147.9 | 147.8 | no | 691.9 / 1 462.7 / 1 665.1 | 784.9 / 1 459.4 / 1 661.8 | 0 | 0 | 0 | 0 | 64 / 68 | 56.9 | 15.7 / 23 | 70.4 / 176 | 61 / 86 | yes |

